from fastapi import FastAPI
from pydantic import BaseModel
import mysql.connector
import os

app = FastAPI()

DB_CONFIG = {
    "host": os.getenv("DB_HOST"),
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "database": os.getenv("DB_NAME")
}

class Persona(BaseModel):
    nombre: str
    edad: int

def get_db():
    return mysql.connector.connect(**DB_CONFIG)

def clasificar_edad(edad):
    if edad <= 12:
        return "Niño"
    elif edad <= 17:
        return "Joven"
    else:
        return "Adulto"


@app.get("/")
def prueba():
    return {"mensaje": "API de clasificación de edades funcionando"}


@app.post("/personas")
def crear_persona(persona: Persona):
    db = get_db()
    cursor = db.cursor()

    cursor.execute(
        "INSERT INTO personas (nombre, edad) VALUES (%s,%s)",
        (persona.nombre, persona.edad)
    )

    db.commit()

    categoria = clasificar_edad(persona.edad)

    return {
        "mensaje": f"{persona.nombre} registrado correctamente",
        "clasificacion": categoria
    }


@app.get("/personas")
def listar_personas():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute("SELECT * FROM personas")
    datos = cursor.fetchall()

    for persona in datos:
        persona["clasificacion"] = clasificar_edad(persona["edad"])

    return datos


@app.put("/personas/{id}")
def actualizar_persona(id: int, persona: Persona):

    db = get_db()
    cursor = db.cursor()

    cursor.execute(
        "UPDATE personas SET nombre=%s, edad=%s WHERE id=%s",
        (persona.nombre, persona.edad, id)
    )

    db.commit()

    return {"mensaje": "Persona actualizada"}


@app.delete("/personas/{id}")
def eliminar_persona(id: int):

    db = get_db()
    cursor = db.cursor()

    cursor.execute("DELETE FROM personas WHERE id=%s", (id,))
    db.commit()

    return {"mensaje": "Persona eliminada"}

import joblib

modelo = joblib.load("model.pkl")

@app.post("/predict")
def predecir(persona: Persona):

    resultado = modelo.predict([[persona.edad]])

    categorias = {
        0: "Niño",
        1: "Joven",
        2: "Adulto"
    }

    return {
        "nombre": persona.nombre,
        "edad": persona.edad,
        "clasificacion": categorias[int(resultado[0])]
    }