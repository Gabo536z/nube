import mysql.connector
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import joblib
import os

db = mysql.connector.connect(
    host=os.getenv("DB_HOST"),
    user=os.getenv("DB_USER"),
    password=os.getenv("DB_PASSWORD"),
    database=os.getenv("DB_NAME")
)

query = "SELECT edad FROM personas"
df = pd.read_sql(query, db)


def clasificar(edad):
    if edad <= 12:
        return 0
    elif edad <= 17:
        return 1
    else:
        return 2


df["categoria"] = df["edad"].apply(clasificar)

X = df[["edad"]]
y = df["categoria"]

modelo = DecisionTreeClassifier()
modelo.fit(X, y)

joblib.dump(modelo, "model.pkl")

print("Modelo entrenado correctamente")