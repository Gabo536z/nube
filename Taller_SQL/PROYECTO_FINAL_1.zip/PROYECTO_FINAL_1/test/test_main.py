import requests

BASE_URL = "http://localhost:8000"

def test_root():
    r = requests.get(BASE_URL + "/")
    assert r.status_code == 200

def test_crud():
    data = {"feature1": 1, "feature2": 2, "target": 3}
    r = requests.post(BASE_URL + "/items", json=data)
    assert r.status_code == 200

    r = requests.get(BASE_URL + "/items")
    assert r.status_code == 200
    assert len(r.json()) > 0

def test_predict():
    data = {"feature1": 2, "feature2": 3}
    r = requests.post(BASE_URL + "/predict", json=data)
    assert r.status_code == 200